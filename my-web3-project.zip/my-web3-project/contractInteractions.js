const Web3 = require('web3');
const fs = require('fs');

// Connect to Ganache or your desired testnet
const web3 = new Web3('http://localhost:7545'); // Replace with your testnet URL if using a public testnet

// Read the ABI and contract address from the deployment step
const abi = JSON.parse(fs.readFileSync('output/MyToken_sol_UniversityToken.abi', 'utf8'));
const contractAddress = '0x35C0f8250168BE1262c913798031D3D2Eaa750eF'; // Replace with your deployed contract address

// Create a contract instance
const myTokenContract = new web3.eth.Contract(abi, contractAddress);

// Example: Call the balanceOf function
async function getBalance(address) {
    const balance = await myTokenContract.methods.balanceOf(address).call();
    console.log(`Balance of ${address}: ${balance} tokens`);
}

// Example: Transfer tokens
async function transferTokens(to, amount) {
    const accounts = await web3.eth.getAccounts();
    const sender = accounts[0];

    // Call the transfer function
    await myTokenContract.methods.transfer(to, amount).send({ from: sender });

    console.log(`Transferred ${amount} tokens from ${sender} to ${to}`);
}

// Example: Get the total supply
async function getTotalSupply() {
    const totalSupply = await myTokenContract.methods.totalSupply().call();
    console.log(`Total Supply: ${totalSupply} tokens`);
}

// Replace '0xRecipientAddress' with an actual Ethereum address
getBalance('0x2622d6a54f7AF95ecfA74c26124AEA5156179972');
transferTokens('0x2622d6a54f7AF95ecfA74c26124AEA5156179972', 100);
getTotalSupply();
