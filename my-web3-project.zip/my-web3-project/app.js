const web3 = new (require('web3'))('HTTP://127.0.0.1:7545');

// Check if a connection to the node is successful
web3.eth.getNodeInfo()
    .then(nodeInfo => {
        console.log('Connected to Ethereum node:', nodeInfo);
    })
    .catch(error => {
        console.error('Error connecting to Ethereum node:', error);
    });
